# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from rest_framework.views import APIView

from rest_framework.response import Response

from datetime import datetime, timedelta, date

from django.shortcuts import render,redirect

from django.http import HttpResponse
from .serializer import *
from .models import *


def leadsort(request):
	if "button1" in request.POST:
		context={}
		lead_id=request.POST.get('lead_id')
		source=request.POST.get('source')
		phone_number=request.POST.get('phone_number')
		data=leads.objects.filter(lead_id=lead_id,Source=source,Phone_Number=phone_number)
		context['data']=leadsSerializer(data,many=True).data
		return render(request,'page2.html',context)


	elif "button2" in request.POST:
		context={}
		followup_id=request.POST.get('followup_id')
		response=request.POST.get('response')
		date_of_followup=request.POST.get('date_of_followup')
		data=follow_up.objects.filter(followup_id=followup_id,Response=response,Date_of_follow_up=date_of_followup)
		context['data']=follow_upSerializer(data,many=True).data
		return render(request,'page3.html',context)
  	else:
		return render(request,'page1.html') 