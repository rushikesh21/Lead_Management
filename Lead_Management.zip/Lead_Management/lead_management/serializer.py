from rest_framework import serializers
from .models import *

class follow_upSerializer(serializers.ModelSerializer):
    class Meta:
        model = follow_up
        fields = '__all__'

class leadsSerializer(serializers.ModelSerializer):
    follow_up=follow_upSerializer(many=True)
    class Meta:
        model = leads
        fields = '__all__'