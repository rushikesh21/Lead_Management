# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import *
class leadsAdmin(admin.ModelAdmin):
	model=leads


admin.site.register(leads, leadsAdmin)

class follow_upAdmin(admin.ModelAdmin):
	model=follow_up


admin.site.register(follow_up, follow_upAdmin)

# Register your models here.
