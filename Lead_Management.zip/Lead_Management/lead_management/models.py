# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

class follow_up(models.Model):
	followup_id=models.IntegerField(blank=True, null=True)
	Date_of_follow_up=models.DateField()
	Response=models.CharField(max_length=1000, blank=True,null=True)
	The_medium_used=models.CharField(max_length=1000, blank=True,null=True)

class leads(models.Model):
	lead_id=models.IntegerField(blank=True, null=True)
	Contact_Person_Name=models.CharField(max_length=1000, blank=True,null=True)
	Phone_Number=models.CharField(max_length=1000, blank=True,null=True)
	Address=models.CharField(max_length=1000, blank=True,null=True)
	Source=models.CharField(max_length=1000, blank=True,null=True)
	Current_Stage=models.CharField(max_length=1000, blank=True,null=True)
	follow_up=models.ManyToManyField(follow_up, blank=True)





# Create your models here.
